import { execFile } from 'child_process';
import express from 'express';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { createServer as createViteServer } from 'vite';

const PORT = Number(process.env.PORT) || 3000;
const ROOT_DIR = process.cwd();

const PYTHON_ZIP_SCRIPT = `
import os, sys, zipfile

root_dir = sys.argv[1]
out_zip = sys.argv[2]

skip_dirs = {
    'node_modules', 'dist', '.git', 'build', 'coverage',
    '.gradle', '.idea', '.cxx', '.externalNativeBuild'
}
skip_prefixes = ('Screenshot_',)

with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for current_root, dirs, files in os.walk(root_dir):
        dirs[:] = [
            d for d in dirs
            if d not in skip_dirs and not os.path.join(current_root, d).endswith(('android/build', 'android/app/build'))
        ]
        for filename in files:
            if filename.startswith(skip_prefixes) or filename.endswith('.log'):
                continue
            full_path = os.path.join(current_root, filename)
            rel_path = os.path.relpath(full_path, root_dir)
            zf.write(full_path, rel_path)
`;

async function startServer() {
  const app = express();

  app.get('/api/download-project-zip', (_req, res) => {
    const tmpZip = path.join(os.tmpdir(), `yahia-azkar-${Date.now()}.zip`);

    execFile('python3', ['-c', PYTHON_ZIP_SCRIPT, ROOT_DIR, tmpZip], { maxBuffer: 1024 * 1024 * 10 }, (err) => {
      if (err || !fs.existsSync(tmpZip)) {
        res.status(500).json({ error: 'تعذر تجهيز ملف ZIP' });
        return;
      }

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="yahia-azkar-project.zip"');
      res.sendFile(tmpZip, (sendErr) => {
        fs.unlink(tmpZip, () => {});
        if (sendErr && !res.headersSent) {
          res.status(500).end();
        }
      });
    });
  });

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.join(ROOT_DIR, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
