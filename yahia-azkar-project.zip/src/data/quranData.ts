import { getCachedSurah, setCachedSurah } from '../utils/storage';

export interface SurahMeta {
  number: number;
  name: string;
  revelationType: 'مكية' | 'مدنية';
  ayahCount: number;
}

export interface SurahAyah {
  numberInSurah: number;
  text: string;
}

export const SURAHS_META: SurahMeta[] = [
  { number: 1, name: 'الفاتحة', revelationType: 'مكية', ayahCount: 7 },
  { number: 2, name: 'البقرة', revelationType: 'مدنية', ayahCount: 286 },
  { number: 3, name: 'آل عمران', revelationType: 'مدنية', ayahCount: 200 },
  { number: 4, name: 'النساء', revelationType: 'مدنية', ayahCount: 176 },
  { number: 5, name: 'المائدة', revelationType: 'مدنية', ayahCount: 120 },
  { number: 6, name: 'الأنعام', revelationType: 'مكية', ayahCount: 165 },
  { number: 7, name: 'الأعراف', revelationType: 'مكية', ayahCount: 206 },
  { number: 8, name: 'الأنفال', revelationType: 'مدنية', ayahCount: 75 },
  { number: 9, name: 'التوبة', revelationType: 'مدنية', ayahCount: 129 },
  { number: 10, name: 'يونس', revelationType: 'مكية', ayahCount: 109 },
  { number: 11, name: 'هود', revelationType: 'مكية', ayahCount: 123 },
  { number: 12, name: 'يوسف', revelationType: 'مكية', ayahCount: 111 },
  { number: 13, name: 'الرعد', revelationType: 'مدنية', ayahCount: 43 },
  { number: 14, name: 'إبراهيم', revelationType: 'مكية', ayahCount: 52 },
  { number: 15, name: 'الحجر', revelationType: 'مكية', ayahCount: 99 },
  { number: 16, name: 'النحل', revelationType: 'مكية', ayahCount: 128 },
  { number: 17, name: 'الإسراء', revelationType: 'مكية', ayahCount: 111 },
  { number: 18, name: 'الكهف', revelationType: 'مكية', ayahCount: 110 },
  { number: 19, name: 'مريم', revelationType: 'مكية', ayahCount: 98 },
  { number: 20, name: 'طه', revelationType: 'مكية', ayahCount: 135 },
  { number: 21, name: 'الأنبياء', revelationType: 'مكية', ayahCount: 112 },
  { number: 22, name: 'الحج', revelationType: 'مدنية', ayahCount: 78 },
  { number: 23, name: 'المؤمنون', revelationType: 'مكية', ayahCount: 118 },
  { number: 24, name: 'النور', revelationType: 'مدنية', ayahCount: 64 },
  { number: 25, name: 'الفرقان', revelationType: 'مكية', ayahCount: 77 },
  { number: 26, name: 'الشعراء', revelationType: 'مكية', ayahCount: 227 },
  { number: 27, name: 'النمل', revelationType: 'مكية', ayahCount: 93 },
  { number: 28, name: 'القصص', revelationType: 'مكية', ayahCount: 88 },
  { number: 29, name: 'العنكبوت', revelationType: 'مكية', ayahCount: 69 },
  { number: 30, name: 'الروم', revelationType: 'مكية', ayahCount: 60 },
  { number: 31, name: 'لقمان', revelationType: 'مكية', ayahCount: 34 },
  { number: 32, name: 'السجدة', revelationType: 'مكية', ayahCount: 30 },
  { number: 33, name: 'الأحزاب', revelationType: 'مدنية', ayahCount: 73 },
  { number: 34, name: 'سبأ', revelationType: 'مكية', ayahCount: 54 },
  { number: 35, name: 'فاطر', revelationType: 'مكية', ayahCount: 45 },
  { number: 36, name: 'يس', revelationType: 'مكية', ayahCount: 83 },
  { number: 37, name: 'الصافات', revelationType: 'مكية', ayahCount: 182 },
  { number: 38, name: 'ص', revelationType: 'مكية', ayahCount: 88 },
  { number: 39, name: 'الزمر', revelationType: 'مكية', ayahCount: 75 },
  { number: 40, name: 'غافر', revelationType: 'مكية', ayahCount: 85 },
  { number: 41, name: 'فصلت', revelationType: 'مكية', ayahCount: 54 },
  { number: 42, name: 'الشورى', revelationType: 'مكية', ayahCount: 53 },
  { number: 43, name: 'الزخرف', revelationType: 'مكية', ayahCount: 89 },
  { number: 44, name: 'الدخان', revelationType: 'مكية', ayahCount: 59 },
  { number: 45, name: 'الجاثية', revelationType: 'مكية', ayahCount: 37 },
  { number: 46, name: 'الأحقاف', revelationType: 'مكية', ayahCount: 35 },
  { number: 47, name: 'محمد', revelationType: 'مدنية', ayahCount: 38 },
  { number: 48, name: 'الفتح', revelationType: 'مدنية', ayahCount: 29 },
  { number: 49, name: 'الحجرات', revelationType: 'مدنية', ayahCount: 18 },
  { number: 50, name: 'ق', revelationType: 'مكية', ayahCount: 45 },
  { number: 51, name: 'الذاريات', revelationType: 'مكية', ayahCount: 60 },
  { number: 52, name: 'الطور', revelationType: 'مكية', ayahCount: 49 },
  { number: 53, name: 'النجم', revelationType: 'مكية', ayahCount: 62 },
  { number: 54, name: 'القمر', revelationType: 'مكية', ayahCount: 55 },
  { number: 55, name: 'الرحمن', revelationType: 'مدنية', ayahCount: 78 },
  { number: 56, name: 'الواقعة', revelationType: 'مكية', ayahCount: 96 },
  { number: 57, name: 'الحديد', revelationType: 'مدنية', ayahCount: 29 },
  { number: 58, name: 'المجادلة', revelationType: 'مدنية', ayahCount: 22 },
  { number: 59, name: 'الحشر', revelationType: 'مدنية', ayahCount: 24 },
  { number: 60, name: 'الممتحنة', revelationType: 'مدنية', ayahCount: 13 },
  { number: 61, name: 'الصف', revelationType: 'مدنية', ayahCount: 14 },
  { number: 62, name: 'الجمعة', revelationType: 'مدنية', ayahCount: 11 },
  { number: 63, name: 'المنافقون', revelationType: 'مدنية', ayahCount: 11 },
  { number: 64, name: 'التغابن', revelationType: 'مدنية', ayahCount: 18 },
  { number: 65, name: 'الطلاق', revelationType: 'مدنية', ayahCount: 12 },
  { number: 66, name: 'التحريم', revelationType: 'مدنية', ayahCount: 12 },
  { number: 67, name: 'الملك', revelationType: 'مكية', ayahCount: 30 },
  { number: 68, name: 'القلم', revelationType: 'مكية', ayahCount: 52 },
  { number: 69, name: 'الحاقة', revelationType: 'مكية', ayahCount: 52 },
  { number: 70, name: 'المعارج', revelationType: 'مكية', ayahCount: 44 },
  { number: 71, name: 'نوح', revelationType: 'مكية', ayahCount: 28 },
  { number: 72, name: 'الجن', revelationType: 'مكية', ayahCount: 28 },
  { number: 73, name: 'المزمل', revelationType: 'مكية', ayahCount: 20 },
  { number: 74, name: 'المدثر', revelationType: 'مكية', ayahCount: 56 },
  { number: 75, name: 'القيامة', revelationType: 'مكية', ayahCount: 40 },
  { number: 76, name: 'الإنسان', revelationType: 'مدنية', ayahCount: 31 },
  { number: 77, name: 'المرسلات', revelationType: 'مكية', ayahCount: 50 },
  { number: 78, name: 'النبأ', revelationType: 'مكية', ayahCount: 40 },
  { number: 79, name: 'النازعات', revelationType: 'مكية', ayahCount: 46 },
  { number: 80, name: 'عبس', revelationType: 'مكية', ayahCount: 42 },
  { number: 81, name: 'التكوير', revelationType: 'مكية', ayahCount: 29 },
  { number: 82, name: 'الانفطار', revelationType: 'مكية', ayahCount: 19 },
  { number: 83, name: 'المطففين', revelationType: 'مكية', ayahCount: 36 },
  { number: 84, name: 'الانشقاق', revelationType: 'مكية', ayahCount: 25 },
  { number: 85, name: 'البروج', revelationType: 'مكية', ayahCount: 22 },
  { number: 86, name: 'الطارق', revelationType: 'مكية', ayahCount: 17 },
  { number: 87, name: 'الأعلى', revelationType: 'مكية', ayahCount: 19 },
  { number: 88, name: 'الغاشية', revelationType: 'مكية', ayahCount: 26 },
  { number: 89, name: 'الفجر', revelationType: 'مكية', ayahCount: 30 },
  { number: 90, name: 'البلد', revelationType: 'مكية', ayahCount: 20 },
  { number: 91, name: 'الشمس', revelationType: 'مكية', ayahCount: 15 },
  { number: 92, name: 'الليل', revelationType: 'مكية', ayahCount: 21 },
  { number: 93, name: 'الضحى', revelationType: 'مكية', ayahCount: 11 },
  { number: 94, name: 'الشرح', revelationType: 'مكية', ayahCount: 8 },
  { number: 95, name: 'التين', revelationType: 'مكية', ayahCount: 8 },
  { number: 96, name: 'العلق', revelationType: 'مكية', ayahCount: 19 },
  { number: 97, name: 'القدر', revelationType: 'مكية', ayahCount: 5 },
  { number: 98, name: 'البينة', revelationType: 'مدنية', ayahCount: 8 },
  { number: 99, name: 'الزلزلة', revelationType: 'مدنية', ayahCount: 8 },
  { number: 100, name: 'العاديات', revelationType: 'مكية', ayahCount: 11 },
  { number: 101, name: 'القارعة', revelationType: 'مكية', ayahCount: 11 },
  { number: 102, name: 'التكاثر', revelationType: 'مكية', ayahCount: 8 },
  { number: 103, name: 'العصر', revelationType: 'مكية', ayahCount: 3 },
  { number: 104, name: 'الهمزة', revelationType: 'مكية', ayahCount: 9 },
  { number: 105, name: 'الفيل', revelationType: 'مكية', ayahCount: 5 },
  { number: 106, name: 'قريش', revelationType: 'مكية', ayahCount: 4 },
  { number: 107, name: 'الماعون', revelationType: 'مكية', ayahCount: 7 },
  { number: 108, name: 'الكوثر', revelationType: 'مكية', ayahCount: 3 },
  { number: 109, name: 'الكافرون', revelationType: 'مكية', ayahCount: 6 },
  { number: 110, name: 'النصر', revelationType: 'مدنية', ayahCount: 3 },
  { number: 111, name: 'المسد', revelationType: 'مكية', ayahCount: 5 },
  { number: 112, name: 'الإخلاص', revelationType: 'مكية', ayahCount: 4 },
  { number: 113, name: 'الفلق', revelationType: 'مكية', ayahCount: 5 },
  { number: 114, name: 'الناس', revelationType: 'مكية', ayahCount: 6 },
];

// Built-in offline Surahs so essential daily reading works immediately even offline
export const BUILTIN_OFFLINE_SURAHS: Record<number, SurahAyah[]> = {
  1: [
    { numberInSurah: 1, text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ' },
    { numberInSurah: 2, text: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ' },
    { numberInSurah: 3, text: 'الرَّحْمَٰنِ الرَّحِيمِ' },
    { numberInSurah: 4, text: 'مَالِكِ يَوْمِ الدِّينِ' },
    { numberInSurah: 5, text: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ' },
    { numberInSurah: 6, text: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ' },
    { numberInSurah: 7, text: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ' },
  ],
  93: [
    { numberInSurah: 1, text: 'وَالضُّحَىٰ' },
    { numberInSurah: 2, text: 'وَاللَّيْلِ إِذَا سَجَىٰ' },
    { numberInSurah: 3, text: 'مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ' },
    { numberInSurah: 4, text: 'وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ' },
    { numberInSurah: 5, text: 'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ' },
    { numberInSurah: 6, text: 'أَلَمْ يَجِدْكَ يَتِيمًا فَآوَىٰ' },
    { numberInSurah: 7, text: 'وَوَجَدَكَ ضَالًّا فَهَدَىٰ' },
    { numberInSurah: 8, text: 'وَوَجَدَكَ عَائِلًا فَأَغْنَىٰ' },
    { numberInSurah: 9, text: 'فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ' },
    { numberInSurah: 10, text: 'وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ' },
    { numberInSurah: 11, text: 'وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ' },
  ],
  94: [
    { numberInSurah: 1, text: 'أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ' },
    { numberInSurah: 2, text: 'وَوَضَعْنَا عَنكَ وِزْرَكَ' },
    { numberInSurah: 3, text: 'الَّذِي أَنقَضَ ظَهْرَكَ' },
    { numberInSurah: 4, text: 'وَرَفَعْنَا لَكَ ذِكْرَكَ' },
    { numberInSurah: 5, text: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا' },
    { numberInSurah: 6, text: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا' },
    { numberInSurah: 7, text: 'فَإِذَا فَرَغْتَ فَانصَبْ' },
    { numberInSurah: 8, text: 'وَإِلَىٰ رَبِّكَ فَارْغَب' },
  ],
  97: [
    { numberInSurah: 1, text: 'إِنَّا أَنزَلْنَاهُ فِي لَيْلَةِ الْقَدْرِ' },
    { numberInSurah: 2, text: 'وَمَا أَدْرَاكَ مَا لَيْلَةُ الْقَدْرِ' },
    { numberInSurah: 3, text: 'لَيْلَةُ الْقَدْرِ خَيْرٌ مِّنْ أَلْفِ شَهْرٍ' },
    { numberInSurah: 4, text: 'تَنَزَّلُ الْمَلَائِكَةُ وَالرُّوحُ فِيهَا بِإِذْنِ رَبِّهِم مِّن كُلِّ أَمْرٍ' },
    { numberInSurah: 5, text: 'سَلَامٌ هِيَ حَتَّىٰ مَطْلَعِ الْفَجْرِ' },
  ],
  103: [
    { numberInSurah: 1, text: 'وَالْعَصْرِ' },
    { numberInSurah: 2, text: 'إِنَّ الْإِنسَانَ لَفِي خُسْرٍ' },
    { numberInSurah: 3, text: 'إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ' },
  ],
  105: [
    { numberInSurah: 1, text: 'أَلَمْ تَرَ كَيْفَ فَعَلَ رَبُّكَ بِأَصْحَابِ الْفِيلِ' },
    { numberInSurah: 2, text: 'أَلَمْ يَجْعَلْ كَيْدَهُمْ فِي تَضْلِيلٍ' },
    { numberInSurah: 3, text: 'وَأَرْسَلَ عَلَيْهِمْ طَيْرًا أَبَابِيلَ' },
    { numberInSurah: 4, text: 'تَرْمِيهِم بِحِجَارَةٍ مِّن سِجِّيلٍ' },
    { numberInSurah: 5, text: 'فَجَعَلَهُمْ كَعَصْفٍ مَّأْكُولٍ' },
  ],
  106: [
    { numberInSurah: 1, text: 'لِإِيلَافِ قُرَيْشٍ' },
    { numberInSurah: 2, text: 'إِيلَافِهِمْ رِحْلَةَ الشِّتَاءِ وَالصَّيْفِ' },
    { numberInSurah: 3, text: 'فَلْيَعْبُدُوا رَبَّ هَٰذَا الْبَيْتِ' },
    { numberInSurah: 4, text: 'الَّذِي أَطْعَمَهُم مِّن جُوعٍ وَآمَنَهُم مِّنْ خَوْفٍ' },
  ],
  108: [
    { numberInSurah: 1, text: 'إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ' },
    { numberInSurah: 2, text: 'فَصَلِّ لِرَبِّكَ وَانْحَرْ' },
    { numberInSurah: 3, text: 'إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ' },
  ],
  109: [
    { numberInSurah: 1, text: 'قُلْ يَا أَيُّهَا الْكَافِرُونَ' },
    { numberInSurah: 2, text: 'لَا أَعْبُدُ مَا تَعْبُدُونَ' },
    { numberInSurah: 3, text: 'وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ' },
    { numberInSurah: 4, text: 'وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ' },
    { numberInSurah: 5, text: 'وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ' },
    { numberInSurah: 6, text: 'لَكُمْ دِينُكُمْ وَلِيَ دِينِ' },
  ],
  110: [
    { numberInSurah: 1, text: 'إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ' },
    { numberInSurah: 2, text: 'وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا' },
    { numberInSurah: 3, text: 'فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا' },
  ],
  112: [
    { numberInSurah: 1, text: 'قُلْ هُوَ اللَّهُ أَحَدٌ' },
    { numberInSurah: 2, text: 'اللَّهُ الصَّمَدُ' },
    { numberInSurah: 3, text: 'لَمْ يَلِدْ وَلَمْ يُولَدْ' },
    { numberInSurah: 4, text: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ' },
  ],
  113: [
    { numberInSurah: 1, text: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ' },
    { numberInSurah: 2, text: 'مِن شَرِّ مَا خَلَقَ' },
    { numberInSurah: 3, text: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ' },
    { numberInSurah: 4, text: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ' },
    { numberInSurah: 5, text: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ' },
  ],
  114: [
    { numberInSurah: 1, text: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ' },
    { numberInSurah: 2, text: 'مَلِكِ النَّاسِ' },
    { numberInSurah: 3, text: 'إِلَٰهِ النَّاسِ' },
    { numberInSurah: 4, text: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ' },
    { numberInSurah: 5, text: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ' },
    { numberInSurah: 6, text: 'مِنَ الْجِنَّةِ وَالنَّاسِ' },
  ],
};

export function toArabicNumerals(num: number): string {
  return String(num).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[Number(d)]);
}

export async function fetchSurahAyahs(surahNumber: number): Promise<SurahAyah[]> {
  // 1. Check IndexedDB cache first
  const cached = await getCachedSurah(surahNumber);
  if (cached && cached.ayahs.length > 0) {
    return cached.ayahs;
  }

  // 2. Check built-in offline dataset
  if (BUILTIN_OFFLINE_SURAHS[surahNumber]) {
    return BUILTIN_OFFLINE_SURAHS[surahNumber];
  }

  // 3. Fetch Uthmani script from AlQuran Cloud API and store in IndexedDB
  const res = await fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}/quran-uthmani`);
  if (!res.ok) {
    throw new Error('تعذر تحميل السورة — تحقق من الاتصال بالإنترنت');
  }
  const json = (await res.json()) as {
    code: number;
    data?: { ayahs?: Array<{ numberInSurah: number; text: string }> };
  };
  const ayahs = json?.data?.ayahs?.map((a) => ({
    numberInSurah: a.numberInSurah,
    text: a.text,
  }));

  if (!ayahs || ayahs.length === 0) {
    throw new Error('لم يتم العثور على آيات السورة');
  }

  await setCachedSurah({ number: surahNumber, ayahs });
  return ayahs;
}

export async function downloadFullQuranOffline(
  onProgress: (done: number, total: number) => void
): Promise<number> {
  const res = await fetch('https://api.alquran.cloud/v1/quran/quran-uthmani');
  if (!res.ok) {
    throw new Error('تعذر الاتصال لتحميل المصحف الشريف');
  }
  const json = (await res.json()) as {
    data?: {
      surahs?: Array<{
        number: number;
        ayahs: Array<{ numberInSurah: number; text: string }>;
      }>;
    };
  };
  const surahs = json?.data?.surahs || [];
  const total = surahs.length;
  for (let i = 0; i < total; i++) {
    const s = surahs[i];
    await setCachedSurah({
      number: s.number,
      ayahs: s.ayahs.map((a) => ({ numberInSurah: a.numberInSurah, text: a.text })),
    });
    if (i % 5 === 0 || i === total - 1) {
      onProgress(i + 1, total);
    }
  }
  return total;
}
