/// <reference lib="webworker" />
import { clientsClaim } from 'workbox-core';
import { ExpirationPlugin } from 'workbox-expiration';
import { CacheableResponsePlugin } from 'workbox-cacheable-response';
import { precacheAndRoute, cleanupOutdatedCaches } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { CacheFirst } from 'workbox-strategies';

declare const self: ServiceWorkerGlobalScope & {
  __WB_MANIFEST: Array<{ url: string; revision: string | null }>;
};

interface ReminderConfigSW {
  enabled: boolean;
  intervalMinutes: number;
  selectedDhikr: string;
  customDhikr: string;
  nextTriggerAt: number | null;
  soundEnabled: boolean;
  soundVolume: number;
  vibrateEnabled: boolean;
  quietHoursEnabled: boolean;
  quietStartHour: number;
  quietEndHour: number;
}

self.skipWaiting();
clientsClaim();

cleanupOutdatedCaches();
precacheAndRoute(self.__WB_MANIFEST || []);

// Cache Google Fonts
registerRoute(
  ({ url }) =>
    url.origin === 'https://fonts.googleapis.com' ||
    url.origin === 'https://fonts.gstatic.com',
  new CacheFirst({
    cacheName: 'google-fonts-cache',
    plugins: [
      new CacheableResponsePlugin({ statuses: [0, 200] }),
      new ExpirationPlugin({ maxEntries: 15, maxAgeSeconds: 60 * 60 * 24 * 365 }),
    ],
  })
);

// Cache Quran API responses for offline reading
registerRoute(
  ({ url }) => url.origin === 'https://api.alquran.cloud',
  new CacheFirst({
    cacheName: 'quran-api-cache',
    plugins: [
      new CacheableResponsePlugin({ statuses: [0, 200] }),
      new ExpirationPlugin({ maxEntries: 120, maxAgeSeconds: 60 * 60 * 24 * 365 }),
    ],
  })
);

const DB_NAME = 'yahia-distrova-db';
const DB_VERSION = 1;
const STORE_KV = 'kv';

function openSWDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_KV)) db.createObjectStore(STORE_KV);
      if (!db.objectStoreNames.contains('quran_surahs')) db.createObjectStore('quran_surahs');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function readReminderConfig(): Promise<ReminderConfigSW | null> {
  try {
    const db = await openSWDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(STORE_KV, 'readonly');
      const req = tx.objectStore(STORE_KV).get('reminderConfig');
      req.onsuccess = () => resolve((req.result as ReminderConfigSW) ?? null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

async function writeReminderConfig(config: ReminderConfigSW): Promise<void> {
  try {
    const db = await openSWDB();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE_KV, 'readwrite');
      tx.objectStore(STORE_KV).put(config, 'reminderConfig');
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Ignore IDB write error in SW
  }
}

function isWithinQuietHours(cfg: ReminderConfigSW): boolean {
  if (!cfg.quietHoursEnabled) return false;
  const h = new Date().getHours();
  if (cfg.quietStartHour <= cfg.quietEndHour) {
    return h >= cfg.quietStartHour && h < cfg.quietEndHour;
  }
  return h >= cfg.quietStartHour || h < cfg.quietEndHour;
}

let swTimer: ReturnType<typeof setTimeout> | null = null;

async function showDhikrNotification(cfg: ReminderConfigSW, isTest = false) {
  if (!isTest && isWithinQuietHours(cfg)) return;

  const phrase = cfg.customDhikr.trim() || cfg.selectedDhikr || 'صلّ على الحبيب محمد ﷺ';
  const title = '✨ {𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب ♥';

  const options: NotificationOptions & {
    vibrate?: number[];
    renotify?: boolean;
    showTrigger?: unknown;
  } = {
    body: `${phrase}\nسبحان الله والحمد لله والله أكبر`,
    icon: '/pwa-192x192.png',
    badge: '/pwa-192x192.png',
    tag: isTest ? `azkar-test-${Date.now()}` : 'azkar-scheduled-reminder',
    renotify: true,
    requireInteraction: false,
    silent: !cfg.soundEnabled,
    data: { url: '/?playReminder=1', phrase },
  };

  if (cfg.vibrateEnabled) {
    options.vibrate = [200, 100, 200];
  }

  await self.registration.showNotification(title, options);

  // Notify any open client windows so audio plays automatically
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of clients) {
    client.postMessage({ type: 'PLAY_REMINDER_AUDIO', phrase });
  }
}

async function scheduleTimestampTrigger(cfg: ReminderConfigSW) {
  // Use Chrome Notification Triggers API if available (survives app close & device reboot)
  const TimestampTriggerCtor = (self as unknown as { TimestampTrigger?: new (ts: number) => unknown }).TimestampTrigger;
  if (!TimestampTriggerCtor || !cfg.nextTriggerAt) return;

  try {
    const existing = await self.registration.getNotifications({ includeTriggered: true } as GetNotificationOptions & { includeTriggered?: boolean });
    for (const n of existing) {
      if (n.tag?.startsWith('azkar-trigger-')) n.close();
    }

    const phrase = cfg.customDhikr.trim() || cfg.selectedDhikr || 'صلّ على الحبيب محمد ﷺ';
    // Schedule next 3 upcoming triggers in OS alarm scheduler
    const intervalMs = Math.max(1, cfg.intervalMinutes) * 60 * 1000;
    for (let i = 0; i < 3; i++) {
      const targetTs = cfg.nextTriggerAt + i * intervalMs;
      await self.registration.showNotification('✨ {𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب ♥', {
        body: phrase,
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        tag: `azkar-trigger-${i}`,
        showTrigger: new TimestampTriggerCtor(targetTs),
        data: { url: '/?playReminder=1', phrase },
      } as NotificationOptions);
    }
  } catch {
    // TimestampTrigger not supported on this browser; fallback timers & periodicSync handle it
  }
}

async function checkAndScheduleNext() {
  if (swTimer) {
    clearTimeout(swTimer);
    swTimer = null;
  }

  const cfg = await readReminderConfig();
  if (!cfg || !cfg.enabled) return;

  const intervalMs = Math.max(1, cfg.intervalMinutes) * 60 * 1000;
  const now = Date.now();

  if (!cfg.nextTriggerAt) {
    cfg.nextTriggerAt = now + intervalMs;
    await writeReminderConfig(cfg);
  } else if (now >= cfg.nextTriggerAt) {
    await showDhikrNotification(cfg);
    // Advance nextTriggerAt cleanly into the future
    const missedSteps = Math.floor((now - cfg.nextTriggerAt) / intervalMs) + 1;
    cfg.nextTriggerAt = cfg.nextTriggerAt + missedSteps * intervalMs;
    await writeReminderConfig(cfg);
  }

  await scheduleTimestampTrigger(cfg);

  const delay = Math.max(1000, (cfg.nextTriggerAt || now + intervalMs) - Date.now());
  // Keep SW timer within safe JS timeout bounds
  if (delay <= 2147483647) {
    swTimer = setTimeout(() => {
      void checkAndScheduleNext();
    }, delay);
  }
}

self.addEventListener('activate', (event) => {
  event.waitUntil(checkAndScheduleNext());
});

self.addEventListener('message', (event) => {
  const data = event.data as { type?: string; config?: ReminderConfigSW } | undefined;
  if (!data?.type) return;

  if (data.type === 'SCHEDULE_REMINDER' && data.config) {
    event.waitUntil(
      writeReminderConfig(data.config).then(() => checkAndScheduleNext())
    );
  } else if (data.type === 'CANCEL_REMINDER') {
    if (swTimer) {
      clearTimeout(swTimer);
      swTimer = null;
    }
    event.waitUntil(
      (async () => {
        const cfg = await readReminderConfig();
        if (cfg) {
          cfg.enabled = false;
          cfg.nextTriggerAt = null;
          await writeReminderConfig(cfg);
        }
      })()
    );
  } else if (data.type === 'TEST_REMINDER') {
    event.waitUntil(
      readReminderConfig().then((cfg) =>
        showDhikrNotification(
          cfg || {
            enabled: true,
            intervalMinutes: 15,
            selectedDhikr: 'اللهم صلّ وسلم وبارك على نبينا محمد ﷺ',
            customDhikr: '',
            nextTriggerAt: Date.now() + 900000,
            soundEnabled: true,
            soundVolume: 0.9,
            vibrateEnabled: true,
            quietHoursEnabled: false,
            quietStartHour: 23,
            quietEndHour: 5,
          },
          true
        )
      )
    );
  } else if (data.type === 'PING_CHECK') {
    event.waitUntil(checkAndScheduleNext());
  }
});

// Periodic Background Sync (fires in background even after app close / reboot)
self.addEventListener('periodicsync', (event: Event) => {
  const syncEvent = event as ExtendableEvent & { tag?: string };
  if (syncEvent.tag === 'azkar-reminder-sync') {
    syncEvent.waitUntil(checkAndScheduleNext());
  }
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = (event.notification.data as { url?: string })?.url || '/?playReminder=1';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.postMessage({ type: 'PLAY_REMINDER_AUDIO' });
          return client.focus();
        }
      }
      return self.clients.openWindow(targetUrl);
    })
  );
});
