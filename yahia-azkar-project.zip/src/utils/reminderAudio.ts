import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { ReminderConfig } from './storage';

export const REMINDER_AUDIO_URL = '/assets/aistudio/______________f40c9c68.mp3';
const NATIVE_CHANNEL_ID = 'azkar_voice_channel';

let activeAudioEl: HTMLAudioElement | null = null;
let keepAliveAudioCtx: AudioContext | null = null;
let keepAliveOscillator: OscillatorNode | null = null;
let keepAliveGain: GainNode | null = null;

async function ensureNativeChannel(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await LocalNotifications.createChannel({
      id: NATIVE_CHANNEL_ID,
      name: 'تذكير الأذكار بالصوت',
      description: 'تنبيهات الأذكار الدورية بصوت التذكير حتى عند إغلاق التطبيق',
      importance: 5,
      visibility: 1,
      sound: 'azkar_reminder.mp3',
      vibration: true,
    });
  } catch {
    // Channel may already exist or API < 26
  }
}

export async function playReminderAudio(volume = 0.9): Promise<boolean> {
  try {
    if (!activeAudioEl) {
      activeAudioEl = new Audio(REMINDER_AUDIO_URL);
    }
    activeAudioEl.pause();
    activeAudioEl.currentTime = 0;
    activeAudioEl.volume = Math.max(0, Math.min(1, volume));
    await activeAudioEl.play();
    return true;
  } catch {
    return false;
  }
}

export function stopReminderAudio(): void {
  if (activeAudioEl) {
    activeAudioEl.pause();
    activeAudioEl.currentTime = 0;
  }
}

export function playGoalChime(): void {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const start = ctx.currentTime + i * 0.11;
      gain.gain.setValueAtTime(0.001, start);
      gain.gain.exponentialRampToValueAtTime(0.14, start + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.45);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.46);
    });
  } catch {
    // Ignore audio context restriction errors
  }
}

/**
 * Enables a near-silent background audio session + MediaSession metadata
 * so mobile browsers do not suspend scheduled audio reminders while locked or minimized.
 */
export function startBackgroundKeepAlive(dhikrTitle: string): void {
  if (Capacitor.isNativePlatform()) return;
  try {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: dhikrTitle || 'صلّ على الحبيب محمد ﷺ',
        artist: '𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀',
        album: '{𝐘𝐀𝐇𝐈𝐀}صلـى عـلى الـحـبيـب♥✨',
        artwork: [
          { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
        ],
      });
    }

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx || keepAliveAudioCtx) return;

    keepAliveAudioCtx = new AudioCtx();
    keepAliveOscillator = keepAliveAudioCtx.createOscillator();
    keepAliveGain = keepAliveAudioCtx.createGain();
    keepAliveOscillator.frequency.value = 20;
    keepAliveGain.gain.value = 0.0001;
    keepAliveOscillator.connect(keepAliveGain);
    keepAliveGain.connect(keepAliveAudioCtx.destination);
    keepAliveOscillator.start();
  } catch {
    // Browser may require user gesture first
  }
}

export function stopBackgroundKeepAlive(): void {
  try {
    if (keepAliveOscillator) {
      keepAliveOscillator.stop();
      keepAliveOscillator.disconnect();
      keepAliveOscillator = null;
    }
    if (keepAliveGain) {
      keepAliveGain.disconnect();
      keepAliveGain = null;
    }
    if (keepAliveAudioCtx) {
      void keepAliveAudioCtx.close();
      keepAliveAudioCtx = null;
    }
  } catch {
    // Ignore cleanup errors
  }
}

export function triggerHaptic(pattern: number | number[] = 25): void {
  if (Capacitor.isNativePlatform()) {
    void Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
    return;
  }
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore vibrate restrictions
    }
  }
}

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (Capacitor.isNativePlatform()) {
    try {
      await ensureNativeChannel();
      const res = await LocalNotifications.requestPermissions();
      return res.display === 'granted' ? 'granted' : 'denied';
    } catch {
      return 'denied';
    }
  }

  if (typeof Notification === 'undefined') return 'denied';
  if (Notification.permission === 'granted') return 'granted';
  try {
    return await Notification.requestPermission();
  } catch {
    return 'denied';
  }
}

export async function syncReminderWithServiceWorker(config: ReminderConfig): Promise<void> {
  // Native Android exact alarm scheduling via @capacitor/local-notifications
  if (Capacitor.isNativePlatform()) {
    try {
      await ensureNativeChannel();
      const pending = await LocalNotifications.getPending();
      if (pending.notifications.length > 0) {
        await LocalNotifications.cancel({
          notifications: pending.notifications.map((n) => ({ id: n.id })),
        });
      }

      if (!config.enabled) return;

      const phrase = config.customDhikr.trim() || config.selectedDhikr || 'صلّ على الحبيب محمد ﷺ';
      const intervalMs = Math.max(1, config.intervalMinutes) * 60 * 1000;
      const firstAt = config.nextTriggerAt && config.nextTriggerAt > Date.now()
        ? config.nextTriggerAt
        : Date.now() + intervalMs;

      // Schedule next 12 exact alarm reminders (persisted across app close & device reboot via Android AlarmManager + BootReceiver)
      const batch = Array.from({ length: 12 }, (_, idx) => ({
        id: 1001 + idx,
        title: '✨ {𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب ♥',
        body: `${phrase}\nسبحان الله والحمد لله والله أكبر`,
        channelId: config.soundEnabled ? NATIVE_CHANNEL_ID : undefined,
        sound: config.soundEnabled ? 'azkar_reminder.mp3' : undefined,
        schedule: {
          at: new Date(firstAt + idx * intervalMs),
          allowWhileIdle: true,
        },
      }));

      await LocalNotifications.schedule({ notifications: batch });
    } catch {
      // Permission not yet granted
    }
    return;
  }

  // Web / PWA Service Worker scheduling
  if (!('serviceWorker' in navigator)) return;
  try {
    const registration = await navigator.serviceWorker.ready;
    const sw = registration.active || navigator.serviceWorker.controller;
    if (sw) {
      sw.postMessage({
        type: config.enabled ? 'SCHEDULE_REMINDER' : 'CANCEL_REMINDER',
        config,
      });
    }

    const periodicReg = registration as ServiceWorkerRegistration & {
      periodicSync?: {
        register: (tag: string, options?: { minInterval: number }) => Promise<void>;
        unregister: (tag: string) => Promise<void>;
      };
    };

    if (periodicReg.periodicSync) {
      if (config.enabled) {
        await periodicReg.periodicSync.register('azkar-reminder-sync', {
          minInterval: Math.max(15, config.intervalMinutes) * 60 * 1000,
        });
      } else {
        await periodicReg.periodicSync.unregister('azkar-reminder-sync');
      }
    }
  } catch {
    // Periodic sync permission may not be granted until PWA installed
  }
}

export async function sendTestReminderToSW(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      await ensureNativeChannel();
      await LocalNotifications.schedule({
        notifications: [
          {
            id: 9999,
            title: '✨ {𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب ♥',
            body: 'سبحان الله والحمد لله والله أكبر — اللهم صلّ وسلم على نبينا محمد ﷺ',
            channelId: NATIVE_CHANNEL_ID,
            sound: 'azkar_reminder.mp3',
            schedule: { at: new Date(Date.now() + 800), allowWhileIdle: true },
          },
        ],
      });
    } catch {
      // Ignore native test error
    }
    return;
  }

  if (!('serviceWorker' in navigator)) return;
  try {
    const registration = await navigator.serviceWorker.ready;
    const sw = registration.active || navigator.serviceWorker.controller;
    sw?.postMessage({ type: 'TEST_REMINDER' });
  } catch {
    // Fallback handled in UI
  }
}
