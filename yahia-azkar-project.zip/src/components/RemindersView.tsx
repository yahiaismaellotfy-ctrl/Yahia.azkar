import React, { useEffect, useState } from 'react';
import {
  Bell,
  BellOff,
  CheckCircle2,
  Clock,
  Moon,
  Play,
  ShieldCheck,
  Volume2,
} from 'lucide-react';
import { DHIKR_PRESETS } from '../data/azkarData';
import {
  playReminderAudio,
  requestNotificationPermission,
  sendTestReminderToSW,
  startBackgroundKeepAlive,
  stopBackgroundKeepAlive,
  triggerHaptic,
} from '../utils/reminderAudio';
import type { ReminderConfig } from '../utils/storage';

interface RemindersViewProps {
  reminder: ReminderConfig;
  onUpdateReminder: (next: ReminderConfig) => void;
}

const INTERVAL_OPTIONS = [
  { label: 'كل دقيقة', value: 1 },
  { label: 'كل ٥ دقائق', value: 5 },
  { label: 'كل ١٠ دقائق', value: 10 },
  { label: 'كل ١٥ دقيقة', value: 15 },
  { label: 'كل ٣٠ دقيقة', value: 30 },
  { label: 'كل ساعة', value: 60 },
  { label: 'كل ساعتين', value: 120 },
];

export const RemindersView: React.FC<RemindersViewProps> = ({
  reminder,
  onUpdateReminder,
}) => {
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );
  const [customMinutes, setCustomMinutes] = useState('');
  const [countdownText, setCountdownText] = useState('--:--');
  const [testFeedback, setTestFeedback] = useState<string | null>(null);

  useEffect(() => {
    const updateCountdown = () => {
      if (!reminder.enabled || !reminder.nextTriggerAt) {
        setCountdownText('متوقف');
        return;
      }
      const diff = Math.max(0, reminder.nextTriggerAt - Date.now());
      const totalSec = Math.floor(diff / 1000);
      const hrs = Math.floor(totalSec / 3600);
      const mins = Math.floor((totalSec % 3600) / 60);
      const secs = totalSec % 60;
      const pad = (n: number) => String(n).padStart(2, '0');
      setCountdownText(hrs > 0 ? `${pad(hrs)}:${pad(mins)}:${pad(secs)}` : `${pad(mins)}:${pad(secs)}`);
    };

    updateCountdown();
    const id = setInterval(updateCountdown, 1000);
    return () => clearInterval(id);
  }, [reminder.enabled, reminder.nextTriggerAt]);

  const handleToggleMaster = async () => {
    const nextEnabled = !reminder.enabled;
    if (nextEnabled) {
      const perm = await requestNotificationPermission();
      setNotifPermission(perm);
      if (reminder.backgroundKeepAlive) {
        startBackgroundKeepAlive(reminder.customDhikr.trim() || reminder.selectedDhikr);
      }
      const nextTriggerAt = Date.now() + reminder.intervalMinutes * 60 * 1000;
      onUpdateReminder({
        ...reminder,
        enabled: true,
        nextTriggerAt,
      });
    } else {
      stopBackgroundKeepAlive();
      onUpdateReminder({
        ...reminder,
        enabled: false,
        nextTriggerAt: null,
      });
    }
  };

  const handleSelectInterval = (minutes: number) => {
    const valid = Math.max(1, Math.min(1440, Math.round(minutes)));
    onUpdateReminder({
      ...reminder,
      intervalMinutes: valid,
      nextTriggerAt: reminder.enabled ? Date.now() + valid * 60 * 1000 : reminder.nextTriggerAt,
    });
  };

  const handleRequestPermission = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
  };

  const handleTestReminder = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);

    if (reminder.soundEnabled) {
      await playReminderAudio(reminder.soundVolume);
    }
    if (reminder.vibrateEnabled) {
      triggerHaptic([150, 80, 150]);
    }
    await sendTestReminderToSW();
    setTestFeedback('تم إرسال إشعار وتنبيه صوتي تجريبي بنجاح');
    setTimeout(() => setTestFeedback(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Master Toggle & Live Status Banner */}
      <section className="rounded-3xl border border-violet-300/20 bg-gradient-to-br from-[#1d1154]/90 via-[#17124d]/85 to-[#0b1f54]/90 p-5 sm:p-6 shadow-2xl">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-4">
            <div
              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border ${
                reminder.enabled
                  ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-300'
                  : 'border-white/15 bg-white/10 text-slate-300'
              }`}
            >
              {reminder.enabled ? <Bell className="h-7 w-7" /> : <BellOff className="h-7 w-7" />}
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-white">نظام التذكير التلقائي</h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-300">
                {reminder.enabled
                  ? `التنبيه القادم خلال ${countdownText} — كل ${reminder.intervalMinutes} دقيقة`
                  : 'قم بتشغيل التذكير ليصلك صوت الذكر والإشعارات حتى في الخلفية'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => void handleToggleMaster()}
              className={`btn-glow min-h-[48px] rounded-2xl px-6 py-2.5 text-sm font-bold text-white shadow-lg whitespace-nowrap shrink-0 ${
                reminder.enabled
                  ? 'bg-gradient-to-l from-rose-600 to-amber-600'
                  : 'bg-gradient-to-l from-emerald-600 to-teal-600'
              }`}
            >
              {reminder.enabled ? 'إيقاف التذكير' : 'تشغيل التذكير الآن'}
            </button>

            <button
              type="button"
              onClick={() => void handleTestReminder()}
              className="btn-glow min-h-[48px] flex items-center gap-2 rounded-2xl border border-amber-300/35 bg-amber-500/20 px-4 py-2.5 text-sm font-bold text-amber-200 whitespace-nowrap shrink-0"
            >
              <Play className="h-4 w-4 shrink-0" />
              <span>تجربة الصوت والإشعار</span>
            </button>
          </div>
        </div>

        {testFeedback && (
          <p className="mt-3 flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{testFeedback}</span>
          </p>
        )}

        {/* Notification Permission & Persistence Status */}
        <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <ShieldCheck className="h-5 w-5 text-blue-300 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed text-slate-200">
              <p className="font-bold text-white">
                حالة إذن الإشعارات في الجهاز:{' '}
                <span
                  className={
                    notifPermission === 'granted'
                      ? 'text-emerald-300'
                      : notifPermission === 'denied'
                      ? 'text-rose-300'
                      : 'text-amber-300'
                  }
                >
                  {notifPermission === 'granted'
                    ? 'مسموح (يعمل في الخلفية)'
                    : notifPermission === 'denied'
                    ? 'مرفوض من إعدادات المتصفح'
                    : 'بانتظار التفعيل'}
                </span>
              </p>
              <p className="mt-1 text-slate-300">
                تُحفظ المواعيد داخل قاعدة بيانات الجهاز (IndexedDB + Service Worker) لتستمر المزامنة حتى بعد إغلاق التطبيق أو إعادة تشغيل الهاتف.
              </p>
            </div>
          </div>

          {notifPermission !== 'granted' && (
            <button
              type="button"
              onClick={() => void handleRequestPermission()}
              className="btn-glow min-h-[44px] rounded-xl bg-violet-600 px-4 py-2 text-xs font-bold text-white whitespace-nowrap shrink-0"
            >
              السماح بالإشعارات
            </button>
          )}
        </div>
      </section>

      {/* Interval & Dhikr Selection Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Interval & Time Window */}
        <section className="lg:col-span-6 space-y-5 rounded-3xl border border-blue-300/20 bg-[#140e44]/80 p-5 sm:p-6 shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Clock className="h-5 w-5 text-blue-300" />
              <span>تحديد الفاصل الزمني بين التذكيرات</span>
            </h3>
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {INTERVAL_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleSelectInterval(opt.value)}
                  className={`btn-glow min-h-[44px] rounded-xl border px-3 py-2 text-xs font-bold ${
                    reminder.intervalMinutes === opt.value
                      ? 'border-amber-300 bg-gradient-to-l from-violet-600 to-blue-600 text-white'
                      : 'border-white/15 bg-white/5 text-slate-200 hover:bg-white/10'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const val = Number(customMinutes);
                if (val >= 1) {
                  handleSelectInterval(val);
                  setCustomMinutes('');
                }
              }}
              className="mt-3 flex gap-2"
            >
              <input
                type="number"
                min={1}
                max={1440}
                value={customMinutes}
                onChange={(e) => setCustomMinutes(e.target.value)}
                placeholder="فاصل مخصص بالدقائق (مثلاً 45)"
                className="min-h-[44px] flex-1 rounded-xl border border-white/15 bg-white/5 px-3 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
              />
              <button
                type="submit"
                className="btn-glow min-h-[44px] rounded-xl bg-blue-600 px-4 text-sm font-bold text-white whitespace-nowrap shrink-0"
              >
                حفظ
              </button>
            </form>
          </div>

          {/* Audio & Background KeepAlive Switches */}
          <div className="space-y-3 border-t border-white/10 pt-4">
            <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
              <div className="flex items-center gap-3">
                <Volume2 className="h-5 w-5 text-amber-300 shrink-0" />
                <div>
                  <p className="text-sm font-bold text-white">تشغيل صوت الذكر تلقائياً</p>
                  <p className="text-xs text-slate-300">
                    نطق: &quot;سبحان الله والحمد لله والله أكبر، اللهم صل وسلم على نبينا محمد&quot;
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={reminder.soundEnabled}
                onChange={(e) =>
                  onUpdateReminder({ ...reminder, soundEnabled: e.target.checked })
                }
                className="h-5 w-5 accent-violet-500"
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
              <div className="flex items-center gap-3">
                <Bell className="h-5 w-5 text-violet-300 shrink-0" />
                <div>
                  <p className="text-sm font-bold text-white">التشغيل المستمر في الخلفية</p>
                  <p className="text-xs text-slate-300">
                    يُبقي الجلسة الصوتية نشطة عند قفل الشاشة أو الخروج من التطبيق
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={reminder.backgroundKeepAlive}
                onChange={(e) => {
                  const active = e.target.checked;
                  if (active && reminder.enabled) {
                    startBackgroundKeepAlive(reminder.customDhikr.trim() || reminder.selectedDhikr);
                  } else {
                    stopBackgroundKeepAlive();
                  }
                  onUpdateReminder({ ...reminder, backgroundKeepAlive: active });
                }}
                className="h-5 w-5 accent-violet-500"
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
              <div className="flex items-center gap-3">
                <Moon className="h-5 w-5 text-blue-300 shrink-0" />
                <div>
                  <p className="text-sm font-bold text-white">تفعيل ساعات الهدوء (عدم الإزعاج ليلاً)</p>
                  <p className="text-xs text-slate-300">
                    إيقاف الإشعارات بين {reminder.quietStartHour}:00 و {reminder.quietEndHour}:00
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={reminder.quietHoursEnabled}
                onChange={(e) =>
                  onUpdateReminder({ ...reminder, quietHoursEnabled: e.target.checked })
                }
                className="h-5 w-5 accent-violet-500"
              />
            </label>
          </div>
        </section>

        {/* Choose Dhikr for Reminder */}
        <section className="lg:col-span-6 rounded-3xl border border-violet-300/20 bg-[#150f44]/80 p-5 sm:p-6 shadow-xl">
          <h3 className="text-base font-bold text-white">اختر نص الذكر في الإشعار</h3>
          <div className="mt-3 space-y-2.5">
            {DHIKR_PRESETS.map((item) => {
              const selected = !reminder.customDhikr.trim() && reminder.selectedDhikr === item.text;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() =>
                    onUpdateReminder({
                      ...reminder,
                      selectedDhikr: item.text,
                      customDhikr: '',
                    })
                  }
                  className={`btn-glow w-full rounded-2xl border p-3.5 text-right ${
                    selected
                      ? 'border-amber-300/60 bg-gradient-to-l from-violet-600/45 to-blue-700/45 text-white'
                      : 'border-white/10 bg-white/5 text-slate-200 hover:bg-white/10'
                  }`}
                >
                  <p className="text-sm font-bold">{item.text}</p>
                </button>
              );
            })}
          </div>

          <div className="mt-4">
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              أو اكتب ذكراً مخصصاً للتذكير به:
            </label>
            <input
              type="text"
              value={reminder.customDhikr}
              onChange={(e) =>
                onUpdateReminder({ ...reminder, customDhikr: e.target.value })
              }
              placeholder="مثال: اللهم صلّ وسلم على نبينا محمد ﷺ"
              className="min-h-[44px] w-full rounded-xl border border-white/15 bg-white/5 px-3.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
            />
          </div>
        </section>
      </div>
    </div>
  );
};
