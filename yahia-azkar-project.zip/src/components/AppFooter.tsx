import React, { useState } from 'react';
import { ExternalLink, Heart, MessageCircle } from 'lucide-react';

export const WHATSAPP_CHANNEL_URL = 'https://whatsapp.com/channel/0029VbBHjuc35fLzD0p4Fu0u';
export const APP_COVER_IMAGE = '/assets/aistudio/file_000000005e0482469815059f1f5a3acd_69bd9b10.png';
export const DEVELOPER_AVATAR_IMAGE = '/assets/aistudio/YAHIA_DISTROVA_2MB_9b532cd6.jpg';

export const AppFooter: React.FC = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <footer className="mt-8 rounded-3xl border border-violet-300/15 bg-gradient-to-br from-violet-950/60 via-[#151146]/70 to-blue-950/60 p-5 sm:p-6 shadow-xl">
      <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          {!imgError ? (
            <img
              src={DEVELOPER_AVATAR_IMAGE}
              alt="شعار المطور YAHIA DISTROVA"
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="h-16 w-16 shrink-0 rounded-2xl border border-amber-300/35 object-cover shadow-lg shadow-violet-950/60"
            />
          ) : (
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-amber-300/35 bg-gradient-to-br from-violet-700 to-blue-700 text-amber-200">
              <Heart className="h-7 w-7" />
            </div>
          )}

          <div className="min-w-0">
            <p className="text-sm font-bold text-amber-200">
              تصميم وتطوير: <span className="tracking-wide text-white">𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀</span>
            </p>
            <p className="mt-1 text-xs leading-relaxed text-slate-300">
              تطبيق {'{𝐘𝐀𝐇𝐈𝐀}'}صلـى عـلى الـحـبيـب♥✨ — لذكر الله حياة أجمل وأجر لا ينتهي
            </p>
          </div>
        </div>

        <a
          href={WHATSAPP_CHANNEL_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-glow inline-flex min-h-[46px] items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-l from-emerald-600 to-teal-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-950/40 whitespace-nowrap shrink-0"
        >
          <MessageCircle className="h-5 w-5 shrink-0" />
          <span>انضم لقناة الواتساب</span>
          <ExternalLink className="h-4 w-4 opacity-80 shrink-0" />
        </a>
      </div>
    </footer>
  );
};
