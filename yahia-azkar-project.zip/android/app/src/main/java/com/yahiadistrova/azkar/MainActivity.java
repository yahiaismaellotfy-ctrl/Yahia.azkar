package com.yahiadistrova.azkar;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
